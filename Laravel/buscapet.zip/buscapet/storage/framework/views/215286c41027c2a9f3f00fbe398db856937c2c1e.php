<h1>dashboard a fazer</h1>
<a href="/">voltar</a><?php /**PATH F:\Programar\Projeto Laravel\arquivos\buscapet\resources\views/dashboard.blade.php ENDPATH**/ ?>