@extends('layouts.main')

@section('title', 'Buscapet - Empresa')

@section('content')

<p>Exibindo empresa {{$id}}</p>



@endsection