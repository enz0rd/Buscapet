@extends('layouts.main')

@section('title', 'Buscapet - Serviços')

@section('content')

<p>Exibindo serviço {{$id}}</p>



@endsection