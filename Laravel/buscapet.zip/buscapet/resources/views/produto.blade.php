@extends('layouts.main')

@section('title', 'Buscapet - Produto')

@section('content')

<p>Exibindo produto {{$id}}</p>


@endsection